""" Componets of the model
"""
import torch.nn as nn
import torch
import torch.nn.functional as F
from torch.nn import Linear
import random
import torch.nn as nn



def xavier_init(m):
    if type(m) == nn.Linear:
        nn.init.xavier_normal_(m.weight)
        if m.bias is not None:
           m.bias.data.fill_(0.0)

class LinearLayer(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.clf = nn.Sequential(nn.Linear(in_dim, out_dim))
        self.clf.apply(xavier_init)

    def forward(self, x):
        x = self.clf(x)
        return x


class GraphConvolution(nn.Module):
    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_features))
        nn.init.xavier_normal_(self.weight.data)
        if self.bias is not None:
            self.bias.data.fill_(0.0)

    def forward(self, x, adj):
        support = torch.mm(x, self.weight)
        output = torch.sparse.mm(adj, support)
        if self.bias is not None:
            return output + self.bias
        else:
            return output

class AE(nn.Module):

    def __init__(self, n_input):
        super(AE, self).__init__()

        self.enc_1 = Linear(n_input, n_input)
        self.z_layer = Linear(n_input, n_input)

        self.dec_1 = Linear(n_input, n_input)

    def forward(self, x):
        z = F.relu(self.enc_1(x))
        x_bar = F.relu(self.dec_1(z))

        return x_bar, z

class EGCAE(nn.Module):
    def __init__(self, num_features):
        super(EGCAE, self).__init__()
        self.conv1 = GraphConvolution(num_features, num_features)

    def forward(self, x, adj,enc_feat1):
        sigma = 0.1
        h = self.conv1(x, adj)
        z = F.normalize((1-sigma)*h + sigma*enc_feat1, p=2, dim=1)
        z = z * x
        A_pred = dot_product_decode(z)
        return A_pred, z

def dot_product_decode(Z):
    A_pred = torch.sigmoid(torch.matmul(Z,Z.t()))
    return A_pred

class SGEGCAE(nn.Module):
    def __init__(self, in_dim, hidden_dim, num_class, dropout):
        super().__init__()
        self.views = len(in_dim)
        self.classes = num_class
        self.dropout = dropout

        self.pre_ae = nn.ModuleList([AE(in_dim[view])  for view in range(self.views)])
        self.pre_gae = nn.ModuleList([EGCAE(in_dim[view])  for view in range(self.views)])
        self.nn = LinearLayer(hidden_dim[0] * self.views, self.views)

        self.TCPConfidenceLayer = nn.ModuleList([LinearLayer(hidden_dim[0], 1) for _ in range(self.views)])
        self.TCPClassifierLayer = nn.ModuleList([LinearLayer(hidden_dim[0], num_class) for _ in range(self.views)])
        self.ClassifierLayer = nn.ModuleList([LinearLayer(hidden_dim[-1], num_class) for _ in range(self.views)])
        self.FeatureEncoder = nn.ModuleList([LinearLayer(in_dim[view], hidden_dim[0]) for view in range(self.views)])

        self.MMClasifier = nn.Sequential(
            nn.Linear(pow(self.classes+1, self.views), pow(self.classes+1, self.views)),
            nn.ReLU(),
            nn.Linear(pow(self.classes+1, self.views), self.classes)
        )

    def forward(self, data_list, adj, label=None, infer=False):
        criterion = torch.nn.CrossEntropyLoss(reduction='none')
        FeatureInfo, x_bar, z_ae, A_pred, z_gae, TCPLogit, TCPConfidence ,z= dict(), dict(), dict(), dict(), dict(), dict(), dict(),dict()
        for view in range(self.views):
            x_bar[view], z_ae[view] = self.pre_ae[view](data_list[view])
            A_pred[view], z_gae[view] = self.pre_gae[view](data_list[view], adj[view], z_ae[view])
            z_gae[view] = self.FeatureEncoder[view](z_gae[view])
            z_gae[view] = F.relu(z_gae[view])
            z_gae[view] = F.dropout(z_gae[view], self.dropout, training=self.training)
            TCPLogit[view] = self.TCPClassifierLayer[view](z_gae[view])
            TCPConfidence[view] = self.TCPConfidenceLayer[view](z_gae[view])
            z_gae[view] = z_gae[view] * TCPConfidence[view]

        n = TCPLogit[0].shape[0]
        A = torch.cat((TCPLogit[0], torch.cuda.FloatTensor(n, 1).fill_(1)), 1)
        B = torch.cat((TCPLogit[1], torch.cuda.FloatTensor(n, 1).fill_(1)), 1)
        C = torch.cat((TCPLogit[2], torch.cuda.FloatTensor(n, 1).fill_(1)), 1)
        A = A.unsqueeze(2)
        B = B.unsqueeze(1)
        fusion_AB = torch.einsum('nxt, nty->nxy', A, B)
        fusion_AB = fusion_AB.flatten(start_dim=1).unsqueeze(1)
        C = C.unsqueeze(1)
        fusion_ABC = torch.einsum('ntx, nty->nxy', fusion_AB, C)
        MMfeature = fusion_ABC.flatten(start_dim=1)
        MMlogit = self.MMClasifier(MMfeature)
        if infer:
            return MMlogit
        MMLoss = torch.mean(criterion(MMlogit, label))

        for view in range(self.views):
            loss_ae = torch.mean(F.mse_loss(x_bar[view], data_list[view]))
            loss_gae = torch.mean(F.mse_loss(A_pred[view].view(-1), adj[view].to_dense().view(-1)))
            MMLoss = MMLoss
            pred = F.softmax(TCPLogit[view], dim=1)
            p_target = torch.gather(input=pred, dim=1, index=label.unsqueeze(dim=1)).view(-1)
            confidence_loss = torch.mean(
                F.mse_loss(TCPConfidence[view].view(-1), p_target) + criterion(TCPLogit[view], label))
            MMLoss = MMLoss + confidence_loss + loss_ae + loss_gae
        return MMLoss, MMlogit

    def infer(self, data_list, adj):
        MMlogit = self.forward(data_list, adj,infer=True)
        return MMlogit




