# BRCA
Breast invasive carcinoma PAM50 subtype classification    
0: Normal-like    
1: Basal-like    
2: HER2-enriched    
3: Luminal A    
4: Luminal B    
